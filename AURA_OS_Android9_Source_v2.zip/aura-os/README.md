# AURA OS — Android TV launcher starter

A minimal Android TV home-screen launcher starter targeting Android 9-compatible devices.

## Build
- JDK 17
- Gradle 8.7
- Android Gradle Plugin 8.5.2
- Android SDK platform 34 / build-tools 34.0.0

Run `gradle assembleDebug` from this directory.

## Current starter features
- Android HOME / Leanback launcher intent filters
- Installed-app grid with TV remote focus and click navigation
- App category filters (basic name-based Media / Tools)
- Long-press app cards to hide/show apps for the current session
- Clock and date
- Dark interface and focus animation

## Not implemented yet
Weather, prayer-time calculations/data, persistent hidden-app preferences, recently-used tracking, custom wallpaper/icon-pack settings, and automatic screensaver. These need additional implementation and, for live data, a location/provider decision.
