package com.auraos.launcher;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private final int BG = Color.rgb(5, 6, 9);
    private final int PANEL = Color.rgb(22, 24, 31);
    private final int TEXT = Color.WHITE;
    private final int MUTED = Color.rgb(158, 164, 178);
    private LinearLayout root;
    private GridLayout appGrid;
    private TextView clockView;
    private final List<AppEntry> apps = new ArrayList<>();
    private final List<String> hidden = new ArrayList<>();
    private String category = "All";

    static class AppEntry {
        String label, pkg;
        android.graphics.drawable.Drawable icon;
        AppEntry(String l, String p, android.graphics.drawable.Drawable i) {
            label=l; pkg=p; icon=i;
        }
    }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        buildUi();
        loadApps();
        renderApps();
        updateClock();
    }

    private GradientDrawable rounded(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color); d.setCornerRadius(radius); return d;
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private void buildUi() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(42, 28, 42, 28);
        root.setBackgroundColor(BG);
        setContentView(root);

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setOrientation(LinearLayout.HORIZONTAL);
        TextView brand = text("A U R A", 27, TEXT, true);
        top.addView(brand, new LinearLayout.LayoutParams(0, -2, 1));
        clockView = text("", 17, MUTED, false);
        top.addView(clockView);
        root.addView(top);

        TextView tagline = text("YOUR SPACE. YOUR ENTERTAINMENT.", 10, MUTED, true);
        LinearLayout.LayoutParams tagLp = new LinearLayout.LayoutParams(-1, -2);
        tagLp.topMargin = 5; tagLp.bottomMargin = 22;
        root.addView(tagline, tagLp);

        LinearLayout filters = new LinearLayout(this);
        filters.setOrientation(LinearLayout.HORIZONTAL);
        String[] tabs = {"All", "Media", "Tools", "Hidden"};
        for (String tab : tabs) {
            Button b = new Button(this);
            b.setText(tab); b.setTextColor(TEXT); b.setAllCaps(false);
            b.setBackground(rounded(PANEL, 28));
            LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-2, 48);
            p.rightMargin = 10;
            filters.addView(b, p);
            b.setOnClickListener(v -> {
                category = tab;
                renderApps();
            });
        }
        root.addView(filters);

        TextView heading = text("YOUR APPS", 13, MUTED, true);
        LinearLayout.LayoutParams h = new LinearLayout.LayoutParams(-1, -2);
        h.topMargin = 24; h.bottomMargin = 12;
        root.addView(heading, h);

        ScrollView scroll = new ScrollView(this);
        appGrid = new GridLayout(this);
        appGrid.setColumnCount(5);
        scroll.addView(appGrid);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));

        TextView footer = text("AURA OS  •  Android TV edition", 10, MUTED, false);
        LinearLayout.LayoutParams f = new LinearLayout.LayoutParams(-1, -2);
        f.topMargin = 12;
        root.addView(footer, f);
    }

    private void loadApps() {
        apps.clear();
        PackageManager pm = getPackageManager();
        Intent query = new Intent(Intent.ACTION_MAIN);
        query.addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER);
        List<ApplicationInfo> infos = pm.getInstalledApplications(PackageManager.GET_META_DATA);
        for (ApplicationInfo info : infos) {
            Intent launch = pm.getLeanbackLaunchIntentForPackage(info.packageName);
            if (launch == null) launch = pm.getLaunchIntentForPackage(info.packageName);
            if (launch == null || info.packageName.equals(getPackageName())) continue;
            String label;
            try { label = pm.getApplicationLabel(info).toString(); }
            catch (Exception e) { label = info.packageName; }
            try { apps.add(new AppEntry(label, info.packageName, pm.getApplicationIcon(info))); }
            catch (Exception ignored) {}
        }
        Collections.sort(apps, (a,b) -> a.label.compareToIgnoreCase(b.label));
    }

    private void renderApps() {
        if (appGrid == null) return;
        appGrid.removeAllViews();
        int shown = 0;
        for (AppEntry app : apps) {
            boolean isHidden = hidden.contains(app.pkg);
            if (category.equals("Hidden") != isHidden) continue;
            if (!category.equals("All") && !category.equals("Hidden")) {
                String s = app.label.toLowerCase(Locale.ROOT);
                if (category.equals("Media") && !(s.contains("youtube") || s.contains("netflix") ||
                    s.contains("prime") || s.contains("spotify") || s.contains("plex"))) continue;
                if (category.equals("Tools") && (s.contains("youtube") || s.contains("netflix") ||
                    s.contains("prime") || s.contains("spotify") || s.contains("plex"))) continue;
            }
            addAppCard(app, shown++);
        }
        if (shown == 0) {
            TextView empty = text("No apps in this category", 16, MUTED, false);
            appGrid.addView(empty);
        }
    }

    private void addAppCard(AppEntry app, int index) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setGravity(Gravity.CENTER);
        card.setPadding(8, 12, 8, 12);
        card.setBackground(rounded(PANEL, 22));
        card.setFocusable(true);
        card.setClickable(true);
        GridLayout.LayoutParams lp = new GridLayout.LayoutParams();
        lp.width = 0; lp.height = 132; lp.columnSpec = GridLayout.spec(index % 5, 1f);
        lp.setMargins(7, 7, 7, 7);
        appGrid.addView(card, lp);

        android.widget.ImageView icon = new android.widget.ImageView(this);
        icon.setImageDrawable(app.icon);
        LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(48, 48);
        card.addView(icon, ip);
        TextView name = text(app.label, 12, TEXT, true);
        name.setGravity(Gravity.CENTER);
        name.setMaxLines(2);
        LinearLayout.LayoutParams np = new LinearLayout.LayoutParams(-1, -2);
        np.topMargin = 8;
        card.addView(name, np);

        card.setOnClickListener(v -> launchApp(app.pkg));
        card.setOnLongClickListener(v -> {
            String action = hidden.contains(app.pkg) ? "Show app" : "Hide app";
            new AlertDialog.Builder(this).setTitle(app.label)
                .setItems(new String[]{action, "Cancel"}, (d, which) -> {
                    if (which == 0) {
                        if (hidden.contains(app.pkg)) hidden.remove(app.pkg);
                        else hidden.add(app.pkg);
                        renderApps();
                    }
                }).show();
            return true;
        });
        card.setOnFocusChangeListener((v, focused) -> {
            v.animate().scaleX(focused ? 1.06f : 1f).scaleY(focused ? 1.06f : 1f)
                .setDuration(140).start();
            v.setBackground(rounded(focused ? Color.rgb(48,52,66) : PANEL, 22));
        });
    }

    private void launchApp(String pkg) {
        Intent launch = getPackageManager().getLeanbackLaunchIntentForPackage(pkg);
        if (launch == null) launch = getPackageManager().getLaunchIntentForPackage(pkg);
        if (launch != null) startActivity(launch);
    }

    private void updateClock() {
        String now = new SimpleDateFormat("EEE, d MMM  •  h:mm a", Locale.getDefault()).format(new Date());
        clockView.setText(now);
        clockView.postDelayed(this::updateClock, 60000);
    }
}
